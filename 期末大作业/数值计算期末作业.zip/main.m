compare1(8,6,10000)
compare2(8,6,10000)
compare3(8,6,10000)
